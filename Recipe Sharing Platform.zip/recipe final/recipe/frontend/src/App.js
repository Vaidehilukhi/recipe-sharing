import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import './App.css';
import SignUp from './Pages/SignUp';
import SignIn from './Pages/SignIn';
import Home_Final from './Pages/Home_Final';
import Contact from './Pages/Contact';
import MostPopular from './Pages/MostPopular';
import AddRecipe from './Pages/Addrecipe';
import AboutUs from './Pages/AboutUs';
import Search from './Pages/Search';
import ForgotPassword from './Pages/ForgotPassword';
import RecipeList from './Pages/RecipeList';

function App() {
  return (
    <div className="App">
      {/* <img src={main_1}  alt="logo" /> */}
      <header className="App-header">
          <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home_Final/>}/>
          <Route path="/SignUp" element={<SignUp/>}/>
          <Route path="/SignIn" element={<SignIn/>}/>
          <Route path="/Contact" element={<Contact/>}/>
          <Route path="/Recipes" element={<AddRecipe/>}/>
          <Route path="/MostPopular" element={<MostPopular/>}/>
          <Route path="/AboutUs" element={<AboutUs/>}/>
          <Route path="/Search" element={<Search/>}/>
          <Route path="/ForgotPassword" element={<ForgotPassword/>}/>
          <Route path="/RecipeList" element={<RecipeList/>}/>
        </Routes>
        </BrowserRouter>
      </header>
    </div>
  );
}

export default App;
