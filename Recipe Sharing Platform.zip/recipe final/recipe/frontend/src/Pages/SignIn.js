import React, { useState, useEffect } from "react";
import loginImage from "../assests/loginImage.jpg";
import "./SignIn.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { ToastContainer, toast, Bounce } from 'react-toastify';
import url from './url'

function SignIn() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [imageLoaded, setImageLoaded] = useState(false);

  const handleLogin = async (event) => {
    event.preventDefault();
    
    if (email === "" || password === "") {
      toast.error("Please fill in all fields", {
        transition: Bounce,
      });
      return alert("Enter the fields");
    }
    
    try {
      const response = await axios.post(`${url}/login`, {
        email: email,
        password: password,
      }, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      console.log(response.data);
      
      if (response.data.login) {
        toast.success('🍇 Wow so easy!', {
          position: "top-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: false,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
          transition: Bounce,
        });
        localStorage.setItem('isLoggedIn', true);
        localStorage.setItem('userEmail', email);
        setTimeout(() => {
          navigate("/");
        }, 1000);
      } else if (response.data.password === false) {
        toast.error("Incorrect password", {
          position: "top-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: false,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
          transition: Bounce,
        });
      } else if (response.data.user === false) {
        toast.warning("User Not Found. Sign up first", {
          position: "top-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: false,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
          transition: Bounce,
        });
      } else {
        console.error("Login failed");
        toast.error("Login failed", {
          position: "top-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: false,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
          transition: Bounce,
        });
      }
    } catch (err) {
      console.error("Error:", err);
      toast.error("An error occurred. Please try again later.", {
        position: "top-center",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: false,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
        transition: Bounce,
      });
    }
  };

  useEffect(() => {
    const image = document.querySelector(".signin-image-section img");
    if (image) {
      image.onload = () => {
        setImageLoaded(true);
      };
    }
  }, []);

  return (
    <div className="signin-container">
      <ToastContainer />
      <div className="asd">
        <div className="signin-image-section">
          <img
            src={loginImage}
            alt="Delicious Food"
            className={imageLoaded ? "loaded" : ""}
          />
        </div>
        <div className="signin-form-section">
          <h2 className="signin-title">Login</h2>
          <form className="signin-form">
            <label className="signin-label" htmlFor="email">
              Email
            </label>
            <input
              className="signin-input email-input"
              type="email"
              id="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />

            <label className="signin-label" htmlFor="password">
              Password
            </label>
            <div className="signin-password-container">
              <input
                className="signin-input password-input"
                type="password"
                id="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <span className="signin-toggle-password">👁</span>
            </div>

            <div className="signin-options">
              <a href="/ForgotPassword" className="forgot-password-link">
                Forgot Password?
              </a>
            </div>

            <button
              className="signin-button"
              type="submit"
              onClick={handleLogin}
            >
              Login
            </button>
            <p className="signup-link">
              Don't have an account? <a href="/signup">SignUp here.</a>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}

export default SignIn;