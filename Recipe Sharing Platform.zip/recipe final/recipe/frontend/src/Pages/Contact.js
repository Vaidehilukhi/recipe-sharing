import React, { useState } from "react";
import "./Contact.css";
import main_2 from '../assests/main_2.jpeg';
const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form Data Submitted:", formData);
    // Add API logic here
  };

  return (
    <div className="contact-container">
      <div className="contact-box">
        <div className="contact-left">
          <img
            src={main_2}
            alt="Contact"
          />
        </div>
        <div className="contact-right">
          <h2 className="contact-title">Quick Contact</h2>
          <form className="contact-form" onSubmit={handleSubmit}>
            <input type="text" name="name" placeholder="Name" onChange={handleChange} />
            <input type="email" name="email" placeholder="Email Address" onChange={handleChange} />
            <input type="tel" name="phone" placeholder="Phone" onChange={handleChange} />
            <textarea name="message" placeholder="Message" onChange={handleChange}></textarea>
            <button type="submit">Submit</button>
          </form>
        </div>
        {/* Contact Details */}
      <div className="contact-details">
        <div className="contact-item">
          <span>📍 Address</span>
          <p>601 Sherwood Ave.</p>
          <p>San Bernardino</p>
        </div>
        <div className="contact-item">
          <span>📞 Phone</span>
          <p>251 546 9442</p>
          <p>630 446 8851</p>
        </div>
        <div className="contact-item">
          <span>📧 Email</span>
          <p>info@wrappixel.com</p>
          <p>123@wrappixel.com</p>
        </div>
      </div>
      </div>

      
    </div>
  );
};

export default Contact;