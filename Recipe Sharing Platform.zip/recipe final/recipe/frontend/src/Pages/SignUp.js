import React, { useState } from "react";
import loginImage from "../assests/signupimage.jpg";
import "./SignUp.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import url from "./url";

function SignUp() {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confpassword, setConfPassword] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");

  const handleSignUp = async (e) => {
    e.preventDefault();

    if (!name || !email || !password || !confpassword || !phoneNumber) {
      return alert("Enter all fields");
    }

    if (password !== confpassword) {
      alert("Passwords do not match!");
      return;
    }

    // Prepend country code if not present (assuming India +91)
    let formattedPhoneNumber = phoneNumber;
    if (!phoneNumber.startsWith("+")) {
      formattedPhoneNumber = `+91${phoneNumber}`;
    }
    console.log("Sending signup with phone:", formattedPhoneNumber); // Debug log

    try {
      const response = await axios.post(
        `${url}/sign`,
        {
          name: name,
          email: email,
          password: password,
          confpassword: confpassword,
          phoneNumber: formattedPhoneNumber, // Use formatted number
        },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (response.status === 201) {
        alert("Signup successful!");
        navigate("/SignIn");
      } else if (response.data.exist) {
        alert("User Exists!");
      } else {
        alert("SignUp failed");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("Error signing up. Try again!");
    }
  };

  return (
    <div className="signup-container">
      <ToastContainer />
      <div className="asdfghyhb">
        <div className="signup-form-section">
          <h2 className="signup-title">Signup</h2>
          <form className="signup-form">
            <label className="signup-label" htmlFor="name">
              Name
            </label>
            <input
              className="signup-input name-input"
              type="text"
              id="name"
              placeholder="Enter your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />

            <label className="signup-label" htmlFor="email">
              Email
            </label>
            <input
              className="signup-input email-input"
              type="email"
              id="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />

            <label className="signup-label" htmlFor="password">
              Password
            </label>
            <div className="signup-password-container">
              <input
                className="signup-input password-input"
                type="password"
                id="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <span className="signup-toggle-password">👁</span>
            </div>

            <label className="signup-label" htmlFor="confpassword">
              Confirm Password
            </label>
            <div className="signup-conf-password-container">
              <input
                className="signup-input password-input"
                type="password" // Fixed type from "confpassword" to "password"
                id="confpassword"
                placeholder="Confirm Password"
                value={confpassword}
                onChange={(e) => setConfPassword(e.target.value)}
              />
              <span className="signup-toggle-password">👁</span>
            </div>

            <label className="signup-label" htmlFor="phoneNumber">
              Phone
            </label>
            <input
              className="signup-input email-input"
              type="tel" // Changed from "number" to "tel" for better phone input
              id="phoneNumber" // Fixed id from "phone" to "phoneNumber" to match label
              placeholder="Enter your Phone Number (e.g., 9328337767)"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
            />

            <button
              className="signup-button"
              type="submit"
              onClick={handleSignUp}
            >
              Signup
            </button>
            <p className="signup-link">
              Already have an account? <a href="/signin">Login here.</a>
            </p>
          </form>
        </div>
        <div className="signup-image-section">
          <img src={loginImage} alt="Signup Visual" />
        </div>
      </div>
    </div>
  );
}

export default SignUp;