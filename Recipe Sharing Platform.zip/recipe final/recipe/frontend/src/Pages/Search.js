import React, { useState, useEffect, useRef } from "react";
import "./Search.css";
import main_2 from "../assests/main_2.jpeg";
import litti from "../assests/images.jpeg"
import images from "../assests/images.png";

const initialRecipes = [
  { id: 1, name: "Litti Chokha", image: litti },
  { id: 2, name: "Garlic Herb Roasted Vegetables", image: main_2 },
  { id: 3, name: "Beef Stir-Fry", image: main_2 },
  { id: 4, name: "Lemon Chicken", image: main_2 },
  { id: 5, name: "Pasta Alfredo", image: main_2 },
  { id: 6, name: "Chicken Salad", image:main_2 },
];

const Search = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredRecipes, setFilteredRecipes] = useState(initialRecipes);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const suggestionsRef = useRef(null);

  useEffect(() => {
    if (!searchQuery.trim()) {
      setFilteredRecipes(initialRecipes);
      setShowSuggestions(false);
      return;
    }

    const filtered = initialRecipes.filter((recipe) =>
      recipe.name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    setFilteredRecipes(filtered);
    setShowSuggestions(filtered.length > 0);
  }, [searchQuery]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (suggestionsRef.current && !suggestionsRef.current.contains(event.target)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSuggestionClick = (suggestion) => {
    setSearchQuery(suggestion);
    setShowSuggestions(false);
  };

  const handleKeyDown = (event) => {
    if (event.key === "ArrowDown" && selectedIndex < filteredRecipes.length - 1) {
      setSelectedIndex(selectedIndex + 1);
    } else if (event.key === "ArrowUp" && selectedIndex > 0) {
      setSelectedIndex(selectedIndex - 1);
    } else if (event.key === "Enter" && selectedIndex >= 0) {
      setSearchQuery(filteredRecipes[selectedIndex].name);
      setShowSuggestions(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    setShowSuggestions(false);
  };

  return (
    <div className="search-container">
      <div
        className="search-header"
        style={{
          background: `linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3)), url(${main_2}) no-repeat center center/cover`,
        }}
      >
        <h1 className="search-title">Find the best recipes in a few steps!</h1>
        <form className="search-form" onSubmit={handleSearch}>
          <div className="search-bar-container" ref={suggestionsRef}>
          <div className="search-input-wrapper">
          <img src={images} alt="Search Icon" className="search-icon" />
            <input
              type="text"
              placeholder="Search for a recipe"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              className="search-input"
            />
            </div>
            {showSuggestions && (
              <ul className="suggestions-list">
                {filteredRecipes.map((recipe, index) => (
                  <li
                    key={recipe.id}
                    onClick={() => handleSuggestionClick(recipe.name)}
                    className={`suggestion-item ${selectedIndex === index ? "selected" : ""}`}
                  >
                    <span className="suggestion-icon">📜</span> {recipe.name}
                  </li>
                ))}
              </ul>
            )}
          </div>
          <button type="submit" className="search-btn">Search now</button>
        </form>
      </div>

      <div className="recipes-grid">
        {filteredRecipes.length > 0 ? (
          filteredRecipes.map((recipe) => (
            <div key={recipe.id} className="recipe-card">
              <div className="recipe-image-container">
                <img src={recipe.image} alt={recipe.name} className="recipe-image" />
                <div className="image-navigation">
                  <span className="nav-arrow left-arrow">◄</span>
                  <span className="image-counter">1/3</span>
                  <span className="nav-arrow right-arrow">►</span>
                </div>
              </div>
              <h3 className="recipe-name">{recipe.name}</h3>
            </div>
          ))
        ) : (
          <p className="no-results">No recipes found. Try a different search!</p>
        )}
      </div>
    </div>
  );
};

export default Search;