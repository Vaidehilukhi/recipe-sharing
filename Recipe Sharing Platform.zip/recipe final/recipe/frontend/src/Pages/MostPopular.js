import React from 'react';
import './MostPopular.css';
import food1 from '../assests/food1.jpg' 

const MostPopular = () => {
  const items = [
    {
      id: 1,
      image: 'https://via.placeholder.com/150',
      description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi in aut illum, eligendi iste dignissimos dolores veniam reiciendis natus rem, iure harum deleniti!',
      rating: 4,
    },
    {
      id: 2,
      image: 'https://via.placeholder.com/150',
      description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi in aut illum, eligendi iste dignissimos dolores veniam reiciendis natus rem, iure harum deleniti!',
      rating: 5,
    },
    {
      id: 3,
      image: 'https://via.placeholder.com/150',
      description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi in aut illum, eligendi iste dignissimos dolores veniam reiciendis natus rem, iure harum deleniti!',
      rating: 3,
    },
    {
      id: 4,
      image: 'https://via.placeholder.com/150',
      description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi in aut illum, eligendi iste dignissimos dolores veniam reiciendis natus rem, iure harum deleniti!',
      rating: 5,
    },
    {
      id: 4,
      image: 'https://via.placeholder.com/150',
      description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi in aut illum, eligendi iste dignissimos dolores veniam reiciendis natus rem, iure harum deleniti!',
      rating: 5,
    },
    {
      id: 4,
      image: 'https://via.placeholder.com/150',
      description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi in aut illum, eligendi iste dignissimos dolores veniam reiciendis natus rem, iure harum deleniti!',
      rating: 5,
    },
  ];

  const renderStars = (rating) => {
    return Array(5)
      .fill(0)
      .map((_, index) => (
        <span key={index} className={index < rating ? 'star-filled' : 'star-empty'}>
          ★
        </span>
      ));
  };

  return (
    <div className="container">
      <div className="header">
       
        <h1 className="title">MOST POPULAR ITEM</h1>
        <p className="description">Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit id et est eveniet officiis.</p>
        <button className="explore-button">Explore More</button>
      </div>
      <div className="items-grid">
        {items.map((item) => (
          <div key={item.id} className="item-card">
            <img src={food1} alt="Item" className="item-image" />
            <div className="item-content">
              <p className="item-description">{item.description}</p>
              <div className="item-rating">{renderStars(item.rating)}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MostPopular;