import React from "react";
import main_2 from "../assests/main_2.jpeg";
import "./AboutUs.css";

const AboutUs = () => {
  const handleLearnMore = () => {
    console.log("Learn More clicked!");
  };

  return (
    <div className="about-container">
      <div className="about-box">
        <div className="about-left">
          <img src={main_2} alt="About Us" />
        </div>
        <div className="about-right">
          <h2 className="about-title">About Us</h2>
          <p className="about-description">
            Welcome to <strong>BiteBoard</strong>, your go-to platform for sharing and discovering delicious recipes! We are passionate about bringing food lovers together to explore, create, and enjoy healthy cooking. Whether you're a seasoned chef or a beginner in the kitchen, our community is here to inspire you with a wide variety of recipes and culinary tips.
          </p>
          <p className="about-description">
            Our mission is to make cooking fun, accessible, and nutritious for everyone. Join us on this flavorful journey and let's create something amazing together!
          </p>
          <button className="about-button" onClick={handleLearnMore}>
            Learn More
          </button>
        </div>
      </div>

      {/* Team Section */}
      <div className="team-section">
        <h2 className="team-title">Meet Our Team</h2>
        <div className="team-members">
          <div className="team-item">
            <span className="team-name">👩‍🍳 Yashvi Shah</span>
            <p>Group Member</p>
            <p>Yashvi collaborated on building BiteBoard, bringing a passion for cooking and recipe sharing to create a platform that inspires food lovers everywhere.</p>
          </div>
          <div className="team-item">
            <span className="team-name">👩‍🎨 Jensi Kachhadiya</span>
            <p>Group Member</p>
            <p>Jensi worked alongside Yashvi to design and develop BiteBoard, ensuring a seamless and visually appealing experience for our users.</p>
          </div>
        </div>
      </div>

      {/* Mission Statement */}
      <div className="mission-section">
        <h2 className="mission-title">Our Mission</h2>
        <p className="mission-description">
          At BiteBoard, we believe that food is more than just sustenance—it's a way to connect, celebrate, and create memories. Our mission is to empower everyone to cook with confidence, explore new flavors, and lead a healthier lifestyle through the joy of cooking.
        </p>
      </div>
    </div>
  );
};

export default AboutUs;