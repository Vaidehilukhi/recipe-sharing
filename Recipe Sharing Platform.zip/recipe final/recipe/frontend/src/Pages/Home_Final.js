import React, { useState, useEffect } from "react";
import main_2 from "../assests/main_2.jpeg";
import "./Home.css";
import Navbar from "./Navbar.js";
import { useNavigate } from "react-router-dom";
import { IoChatbubbleEllipsesOutline } from "react-icons/io5";
import "./Chatbot.css";

export default function Home_Final() {
  const navigate = useNavigate();
  const [isChatbotOpen, setIsChatBotOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(localStorage.getItem("isLoggedIn") === "true"); // Track login status
  const [messages, setMessages] = useState([
    { text: "Hello, how can I assist you today?", sender: "bot" }, // Fallback message while fetching
  ]);
  const [showOptions, setShowOptions] = useState(false);
  const [conversationStep, setConversationStep] = useState(0);
  const [isImageLoaded, setIsImageLoaded] = useState(false);

  // Fetch the user's name or set guest greeting based on login status
  useEffect(() => {
    const fetchUserName = async () => {
      try {
        const userEmail = localStorage.getItem("userEmail");

        if (!isLoggedIn || !userEmail) {
          // If not logged in or no email, use a guest greeting
          setMessages([{ text: "Hello Guest, how can I assist you today?", sender: "bot" }]);
          return;
        }

        // Make an API call to fetch the user's name
        const response = await fetch(`http://localhost:5000/api/user?email=${encodeURIComponent(userEmail)}`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        });

        if (!response.ok) {
          throw new Error("Failed to fetch user data");
        }

        const data = await response.json();
        const userName = data.name || "Guest"; // Fallback to "Guest" if name is not found
        setMessages([{ text: `Hello ${userName}, how can I assist you today?`, sender: "bot" }]);
      } catch (error) {
        console.error("Error fetching user name:", error);
        setMessages([{ text: "Hello Guest, how can I assist you today?", sender: "bot" }]);
      }
    };

    fetchUserName();
  }, [isLoggedIn]); // Re-run when isLoggedIn changes

  // Listen for changes to localStorage (e.g., when logging out)
  useEffect(() => {
    const handleStorageChange = (e) => {
      const loggedIn = localStorage.getItem("isLoggedIn") === "true";
      setIsLoggedIn(loggedIn);
      // If the user logs out, ensure the greeting is reset
      if (!loggedIn) {
        setMessages([{ text: "Hello Guest, how can I assist you today?", sender: "bot" }]);
      }
    };

    // Listen for storage events (e.g., when localStorage changes in another tab)
    window.addEventListener("storage", handleStorageChange);

    // Also check on mount and when navigating
    handleStorageChange();

    return () => {
      window.removeEventListener("storage", handleStorageChange);
    };
  }, []);

  // Reset greeting when the component unmounts or user navigates away
  useEffect(() => {
    return () => {
      // Reset the greeting when the component unmounts (e.g., after navigating to /SignIn)
      setMessages([{ text: "Hello Guest, how can I assist you today?", sender: "bot" }]);
    };
  }, []);

  // Predefined questions and responses for initial step
  const initialQuestions = [
    { question: "I need support help", response: "Great! How can we help you?" },
    { question: "What help do you want?", response: "I can assist you with recipes, navigation, or website features!" },
    { question: "How to post a recipe on our website?", response: "To post a recipe, go to the 'Submit Recipe' page, fill out the form, and click 'Submit'!" },
    { 
      question: "What are the most popular recipes?", 
      response: "Check out the 'Most Popular' section for trending recipes!",
      navigateTo: "/MostPopular" // Define the route to navigate to
    },
  ];

  // Login check options
  const loginCheckOptions = [
    { question: "Yes", response: "Great! Please create a ticket in the Support Center." },
    { question: "No", response: "Please sign up first to proceed." },
  ];

  // Support-related questions after login confirmation
  const supportQuestions = [
    { question: "Create a ticket in Support Center", response: "Log in to your account and submit a ticket in the Support Center. Our team will contact you shortly." },
    { question: "Other support issues", response: "Please describe your issue in the Support Center after logging in." },
  ];

  useEffect(() => {
    const img = new Image();
    img.src = main_2;
    img.onload = () => {
      setIsImageLoaded(true);
    };
  }, []);

  useEffect(() => {
    if (messages.length === 1 && messages[0].sender === "bot") {
      setTimeout(() => {
        setShowOptions(true);
      }, 1000);
    }
  }, [messages]);

  const handleQuestionClick = (question, response, navigateTo) => {
    setMessages([...messages, { text: question, sender: "user" }]);

    setTimeout(() => {
      if (conversationStep === 0 && question === "I need support help") {
        setMessages((prev) => [...prev, { text: "Are you already logged in?", sender: "bot" }]);
        setConversationStep(1);
      } else if (conversationStep === 1) {
        setMessages((prev) => [...prev, { text: response, sender: "bot" }]);
        if (question === "No") {
          setTimeout(() => {
            navigate("/signup");
          }, 1000);
        } else if (question === "Yes") {
          setConversationStep(2);
        }
      } else if (conversationStep === 2) {
        setMessages((prev) => [...prev, { text: response, sender: "bot" }]);
      } else {
        // Default response for other initial questions
        setMessages((prev) => [...prev, { text: response, sender: "bot" }]);
        // Check if there's a navigateTo field and navigate if present
        if (navigateTo) {
          setTimeout(() => {
            navigate(navigateTo);
          }, 1000); // Delay navigation to allow the user to see the bot's response
        }
      }
    }, 1000);
  };

  function MoreRecipes() {
    navigate("/MostPopular");
  }

  return (
    <div className={`header ${isImageLoaded ? "loaded" : "loading"}`}>
      <Navbar />
      <div className={`poijmngf ${isImageLoaded ? "animate" : ""}`}>
        <span>Healthy Cooking Recipes</span>
        <p className="and">And the right nutrition</p>
        <button className="get-started" onClick={MoreRecipes}>
          More Recipes
        </button>
      </div>
      <img src={main_2} alt="Food Display" className="abcd" />
      <div
        className="chatbot-icon"
        onClick={() => setIsChatBotOpen(!isChatbotOpen)}
      >
        <IoChatbubbleEllipsesOutline size={30} />
      </div>

      {isChatbotOpen && (
        <div className="chatbot-box">
          <div className="chatbot-header">
            <h3>Chat with us</h3>
            <button
              style={{ backgroundColor: "#FFA733", color: "white" }}
              onClick={() => setIsChatBotOpen(false)}
            >
              ×
            </button>
          </div>
          <div className="chatbot-content">
            {messages.map((msg, i) => (
              <div
                key={i}
                style={{ textAlign: msg.sender === "user" ? "right" : "left" }}
              >
                <p
                  style={{
                    backgroundColor: msg.sender === "user" ? "#FFB347" : "#FFD580",
                    color: msg.sender === "user" ? "white" : "black",
                    padding: "8px 12px",
                    borderRadius: "15px",
                    display: "inline-block",
                    maxWidth: "80%",
                  }}
                >
                  {msg.text}
                </p>
              </div>
            ))}
          </div>
          <div className="chatbot-input">
            {showOptions && (
              <div style={{ display: "flex", flexDirection: "column", gap: "8px", alignItems: "center" }}>
                {conversationStep === 0 &&
                  initialQuestions.map((item, index) => (
                    <button
                      key={index}
                      className="chatbot-button"
                      onClick={() => handleQuestionClick(item.question, item.response, item.navigateTo)}
                    >
                      {item.question}
                    </button>
                  ))}
                {conversationStep === 1 && (
                  <div className="yes-no-container">
                    {loginCheckOptions.map((item, index) => (
                      <button
                        key={index}
                        className="chatbot-yes-no-button"
                        onClick={() => handleQuestionClick(item.question, item.response)}
                      >
                        {item.question}
                      </button>
                    ))}
                  </div>
                )}
                {conversationStep === 2 &&
                  supportQuestions.map((item, index) => (
                    <button
                      key={index}
                      className="chatbot-button"
                      onClick={() => handleQuestionClick(item.question, item.response)}
                    >
                      {item.question}
                    </button>
                  ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}