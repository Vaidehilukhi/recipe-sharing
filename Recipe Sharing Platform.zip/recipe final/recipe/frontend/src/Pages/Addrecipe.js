import React, { useState } from "react";
import axios from "axios";
import "./Addrecipe.css"

const ingredientSuggestions = [
  "Tomatoes", "Onions", "Garlic", "Olive Oil", "Chicken", "Cheese", "Bell Peppers", "Spinach", "Eggs"
];

const AddRecipe = () => {
  const [title, setTitle] = useState("");
  const [ingredientInput, setIngredientInput] = useState("");
  const [ingredients, setIngredients] = useState([]);
  const [instructions, setInstructions] = useState("");
  const [showPopup, setShowPopup] = useState(false);

  const handleAddIngredient = (e) => {
    e.preventDefault();
    const trimmed = ingredientInput.trim();
    if (trimmed && !ingredients.includes(trimmed)) {
      setIngredients([...ingredients, trimmed]);
    }
    setIngredientInput("");
  };

  const handleRemoveIngredient = (item) => {
    setIngredients(ingredients.filter((i) => i !== item));
  };

  const handleSuggestionClick = (item) => {
    if (!ingredients.includes(item)) {
      setIngredients([...ingredients, item]);
    }
    setIngredientInput("");
  };

  const filteredSuggestions = ingredientSuggestions.filter(
    (item) =>
      item.toLowerCase().includes(ingredientInput.toLowerCase()) &&
      !ingredients.includes(item)
  );

  const submitRecipe = async (e) => {
    e.preventDefault();
    const newRecipe = {
      title,
      ingredients: ingredients.join(", "),
      instructions
    };
    await axios.post("http://localhost:5000/api/recipes", newRecipe);
    setShowPopup(true);
    setTitle("");
    setIngredients([]);
    setInstructions("");
    setIngredientInput("");
  };

  return (
    <div className="recipe-popup-wrapper">
      <div className="recipe-popup">
        <h2>Add New Recipe</h2>
        <form onSubmit={submitRecipe}>
          <input
            type="text"
            placeholder="Recipe Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />

          <div className="ingredient-dropdown">
            <div className="tags-container">
              {ingredients.map((item) => (
                <span key={item} className="tag">
                  {item}
                  <button onClick={() => handleRemoveIngredient(item)}>×</button>
                </span>
              ))}
            </div>
            <input
              type="text"
              placeholder="Add ingredient"
              value={ingredientInput}
              onChange={(e) => setIngredientInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAddIngredient(e)}
            />
            {ingredientInput && filteredSuggestions.length > 0 && (
              <ul className="suggestions-list">
                {filteredSuggestions.map((item) => (
                  <li key={item} onClick={() => handleSuggestionClick(item)}>
                    {item}
                  </li>
                ))}
              </ul>
            )}
          </div>

          <textarea
            placeholder="Cooking Instructions"
            value={instructions}
            onChange={(e) => setInstructions(e.target.value)}
            required
          />

          <button type="submit">Add Recipe</button>
        </form>
      </div>

      {showPopup && (
        <div className="custom-modal">
          <div className="modal-content">
            <h3>Success!</h3>
            <p>Recipe Added Successfully! 🎉</p>
            <button onClick={() => setShowPopup(false)}>OK</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AddRecipe;
