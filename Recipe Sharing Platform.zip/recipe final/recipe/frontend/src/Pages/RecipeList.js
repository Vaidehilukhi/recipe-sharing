import React, { useEffect, useState } from "react";
import axios from "axios";
import "./RecipeList.css";

const RecipeList = () => {
  const [recipes, setRecipes] = useState([]);
  const [editingRecipe, setEditingRecipe] = useState(null);
  const [editTitle, setEditTitle] = useState("");
  const [editIngredients, setEditIngredients] = useState("");
  const [editInstructions, setEditInstructions] = useState("");

  const fetchRecipes = async () => {
    const res = await axios.get("http://localhost:5000/api/recipes");
    setRecipes(res.data);
  };

  useEffect(() => {
    fetchRecipes();
  }, []);

  const deleteRecipe = async (id) => {
    await axios.delete(`http://localhost:5000/api/recipes/${id}`);
    fetchRecipes();
  };

  const openEditModal = (recipe) => {
    setEditingRecipe(recipe);
    setEditTitle(recipe.title);
    setEditIngredients(recipe.ingredients);
    setEditInstructions(recipe.instructions);
  };

  const handleUpdate = async () => {
    await axios.put(`http://localhost:5000/api/recipes/${editingRecipe._id}`, {
      title: editTitle,
      ingredients: editIngredients,
      instructions: editInstructions,
    });
    setEditingRecipe(null);
    fetchRecipes();
  };

  return (
    <div className="recipe-container">
      <h2>📋 Recipe List</h2>

      {recipes.length === 0 ? (
        <p>No recipes available. Please add some!</p>
      ) : (
        recipes.map((r) => (
          <div className="recipe-card" key={r._id}>
            <h3>{r.title}</h3>
            <p><strong>Ingredients:</strong> {r.ingredients}</p>
            <p><strong>Instructions:</strong> {r.instructions}</p>
            <div className="btn-group">
              <button onClick={() => openEditModal(r)}>✏️ Edit</button>
              <button className="delete-btn" onClick={() => deleteRecipe(r._id)}>🗑️ Delete</button>
            </div>
          </div>
        ))
      )}

      {editingRecipe && (
        <div className="modal-overlay">
          <div className="modal">
            <h3>Edit Recipe</h3>
            <input
              type="text"
              value={editTitle}
              onChange={(e) => setEditTitle(e.target.value)}
              placeholder="Title"
            />
            <textarea
              value={editIngredients}
              onChange={(e) => setEditIngredients(e.target.value)}
              placeholder="Ingredients"
            />
            <textarea
              value={editInstructions}
              onChange={(e) => setEditInstructions(e.target.value)}
              placeholder="Instructions"
            />
            <div className="modal-actions">
              <button onClick={handleUpdate}>✅ Update</button>
              <button onClick={() => setEditingRecipe(null)}>❌ Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RecipeList;
