import React from "react";
import "./Home.css";
import { useNavigate, Link } from 'react-router-dom';

export default function Navbar() {
  const navigate = useNavigate();
  const isLoggedIn = JSON.parse(localStorage.getItem('isLoggedIn')) || false;

  const handleLogin = () => {
    navigate('/SignIn');
  };

  const handleSign = () => {
    navigate('/SignUp');
  };

  const handleLogout = () => {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('userEmail');
    window.dispatchEvent(new Event("storage"));
    navigate('/SignIn');
  };

  return (
    <nav className="navbar">
      <div className="logo">BiteBoard</div>
      <ul className="navbar-links">
        <li><Link to="/">Home</Link></li>
        <li><Link to="/Recipes">Recipes</Link></li>
        <li><Link to="/RecipeList" className="nested-link">Recipe List</Link></li>
        <li><Link to="/AboutUs">About</Link></li>
        <li><Link to="/Contact">Contact</Link></li>
        <li><Link to="/Search">Search More Recipes</Link></li>
      </ul>

      {isLoggedIn ? (
        <button className="signup-btn" onClick={handleLogout}>LogOut</button>
      ) : (
        <div className="auth-buttons"> 
          <button className="login-btn" onClick={handleLogin}>Login</button>
          <button className="signup-btn" onClick={handleSign}>Sign Up</button>
        </div>
      )}
    </nav>
  );
}
