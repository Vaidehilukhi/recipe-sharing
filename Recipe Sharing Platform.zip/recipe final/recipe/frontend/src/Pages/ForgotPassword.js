import React, { useState, useEffect } from "react";
import loginImage from "../assests/loginImage.jpg";
import "./ForgotPassword.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { ToastContainer, toast, Bounce } from "react-toastify";
import url from "./url";

function ForgotPassword() {
  const navigate = useNavigate();
  const [phoneNumber, setPhoneNumber] = useState("");
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [step, setStep] = useState(1);
  const [imageLoaded, setImageLoaded] = useState(false);

  const handleSendOtp = async (event) => {
    event.preventDefault();

    if (!phoneNumber) {
      toast.error("Please enter your phone number", { transition: Bounce });
      return;
    }

    // Prepend country code if not present
    let formattedPhoneNumber = phoneNumber;
    if (!phoneNumber.startsWith("+")) {
      formattedPhoneNumber = `+91${phoneNumber}`; // Assuming India
    }

    try {
      console.log("Sending to:", `${url}/send-otp`, "with:", formattedPhoneNumber);
      const response = await axios.post(`${url}/send-otp`, {
        phoneNumber: formattedPhoneNumber,
      }, {
        headers: { "Content-Type": "application/json" },
      });

      if (response.data.success) {
        toast.success("OTP sent successfully!", {
          position: "top-center",
          theme: "dark",
          transition: Bounce,
        });
        setStep(2);
      } else {
        toast.warning(response.data.message, {
          position: "top-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: false,
          pauseOnHover: true,
          draggable: true,
          theme: "dark",
          transition: Bounce,
          onClose: () => navigate("/signup"),
        });
      }
    } catch (err) {
      toast.error("Error sending OTP. Please try again.", {
        position: "top-center",
        theme: "dark",
        transition: Bounce,
      });
    }
  };

  const handleVerifyOtp = async (event) => {
    event.preventDefault();

    if (!otp) {
      toast.error("Please enter the OTP", { transition: Bounce });
      return;
    }

    let formattedPhoneNumber = phoneNumber;
    if (!phoneNumber.startsWith("+")) {
      formattedPhoneNumber = `+91${phoneNumber}`;
    }

    try {
      const response = await axios.post(`${url}/verify-otp`, {
        phoneNumber: formattedPhoneNumber,
        otp: otp,
      }, {
        headers: { "Content-Type": "application/json" },
      });

      if (response.data.verified) {
        toast.success("OTP verified successfully!", {
          position: "top-center",
          theme: "dark",
          transition: Bounce,
        });
        setStep(3);
      } else {
        toast.error(response.data.message || "Invalid OTP", {
          position: "top-center",
          theme: "dark",
          transition: Bounce,
        });
      }
    } catch (err) {
      toast.error("Error verifying OTP", {
        position: "top-center",
        theme: "dark",
        transition: Bounce,
      });
    }
  };

  const handleResetPassword = async (event) => {
    event.preventDefault();

    if (!newPassword) {
      toast.error("Please enter a new password", { transition: Bounce });
      return;
    }

    let formattedPhoneNumber = phoneNumber;
    if (!phoneNumber.startsWith("+")) {
      formattedPhoneNumber = `+91${phoneNumber}`;
    }

    try {
      const response = await axios.post(`${url}/reset-password`, {
        phoneNumber: formattedPhoneNumber,
        newPassword: newPassword,
      }, {
        headers: { "Content-Type": "application/json" },
      });

      if (response.data.success) {
        toast.success("Password reset successfully!", {
          position: "top-center",
          theme: "dark",
          transition: Bounce,
        });
        setTimeout(() => {
          navigate("/signin");
        }, 1000);
      }
    } catch (err) {
      toast.error("Error resetting password", {
        position: "top-center",
        theme: "dark",
        transition: Bounce,
      });
    }
  };

  useEffect(() => {
    const image = document.querySelector(".forgot-password-image-section img");
    if (image) {
      image.onload = () => setImageLoaded(true);
    }
  }, []);

  return (
    <div className="forgot-password-container">
      <ToastContainer />
      <div className="asd">
        <div className="forgot-password-image-section">
          <img
            src={loginImage}
            alt="Delicious Food"
            className={imageLoaded ? "loaded" : ""}
          />
        </div>
        <div className="forgot-password-form-section">
          <h2 className="forgot-password-title">
            {step === 1 ? "Forgot Password" : step === 2 ? "Verify OTP" : "Reset Password"}
          </h2>
          <form className="forgot-password-form">
            {step === 1 && (
              <>
                <label className="forgot-password-label" htmlFor="phoneNumber">
                  Phone Number
                </label>
                <input
                  className="forgot-password-input"
                  type="tel"
                  id="phoneNumber"
                  placeholder="Enter your phone number (e.g., 9328331234)"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                />
                <button
                  className="forgot-password-button"
                  type="submit"
                  onClick={handleSendOtp}
                >
                  Send OTP
                </button>
              </>
            )}

            {step === 2 && (
              <>
                <label className="forgot-password-label" htmlFor="otp">
                  Enter OTP
                </label>
                <input
                  className="forgot-password-input"
                  type="text"
                  id="otp"
                  placeholder="Enter the OTP"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                />
                <button
                  className="forgot-password-button"
                  type="submit"
                  onClick={handleVerifyOtp}
                >
                  Verify OTP
                </button>
              </>
            )}

            {step === 3 && (
              <>
                <label className="forgot-password-label" htmlFor="newPassword">
                  New Password
                </label>
                <div className="forgot-password-password-container">
                  <input
                    className="forgot-password-input"
                    type="password"
                    id="newPassword"
                    placeholder="Enter new password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                  />
                  <span className="forgot-password-toggle-password">👁</span>
                </div>
                <button
                  className="forgot-password-button"
                  type="submit"
                  onClick={handleResetPassword}
                >
                  Reset Password
                </button>
              </>
            )}

            <p className="back-to-login">
              <a href="/signin">Back to Login</a>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}

export default ForgotPassword;