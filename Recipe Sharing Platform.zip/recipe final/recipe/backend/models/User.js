const mongoose =require('mongoose');
const Userschema=new mongoose.Schema({
    name:{
        type:String,
        required:true,
        max:25
    },
    email:{
        type:String,
        required:true,
        max:50
    },
    password:{
        type:String,
        required:true,
        min:5,
    },
    confpassword:{
        type:String,
        required:true,
        min:5,
    },
    phoneNumber:{
        type:String,
        required:true,
        max:10,
    },
    otp: { type: String },
    otpExpires: { type: Date }

});
const User=mongoose.model("User",Userschema);
module.exports = User;