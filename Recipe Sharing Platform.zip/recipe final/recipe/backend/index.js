require("dotenv").config();
const express = require("express");
const app = express();
const User = require("./models/User");
const mongoose = require("mongoose");
const cors = require("cors");
const recipeRoutes = require("./routes/recipeRoutes");
const nodemailer = require("nodemailer");
const userRoute = require("./routes/userRoute");
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose
  .connect("mongodb://localhost:27017/recipe_sharing", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.log("MongoDB connection error:", err));

// Twilio Setup
const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const client = require("twilio")(accountSid, authToken);

// Function to generate a random 6-digit OTP
const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

// Send OTP via SMS
const sendSMS = async (to, body) => {
  let msgOptions = {
    from: process.env.TWILIO_PHONE_NUMBER,
    to: to,
    body,
  };
  try {
    const message = await client.messages.create(msgOptions);
    console.log("SMS sent:", message.sid);
    return true;
  } catch (err) {
    console.error("Error sending SMS:", err);
    return false;
  }
};

// Login Endpoint
app.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    console.log("Login request:", req.body);
    const user = await User.findOne({ email });

    if (!user) {
      return res.json({ user: false });
    }
    if (user.password === password) {
      return res.json({ login: true });
    } else {
      return res.json({ password: false });
    }
  } catch (error) {
    console.error("Error finding user:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Sign Up Endpoint
app.post("/sign", async (req, res) => {
  try {
    let { name, email, password, confpassword, phoneNumber } = req.body;
    console.log("Signup request:", req.body);

    // Ensure phone number is in E.164 format
    if (!phoneNumber.startsWith("+")) {
      phoneNumber = `+91${phoneNumber}`; // Assuming India; adjust as needed
    }

    const user = await User.findOne({ email });
    if (user) {
      console.log("User already exists");
      return res.json({ exist: true });
    }

    const newUser = new User({
      name,
      email,
      password,
      confpassword,
      phoneNumber,
    });
    await newUser.save();

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "shahyashvi202@gmail.com",
        pass: "sjix kzjs oadm xivg", // Use an App Password if 2FA is enabled
      },
    });

    const mailOptions = {
      from: "shahyashvi202@gmail.com",
      to: email,
      subject: "Welcome to Recipe Sharing!",
      text: "Hello! You've successfully signed up.",
      html: "<b>Hello! You've successfully signed up.</b>",
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error("Error sending email:", error);
      } else {
        console.log("Email sent:", info.messageId);
      }
    });

    return res.status(201).json({ message: "User Signed Up Successfully" });
  } catch (error) {
    console.error("Error in /sign:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Send OTP Endpoint
app.post("/send-otp", async (req, res) => {
  let { phoneNumber } = req.body;
  console.log("Received /send-otp request with:", phoneNumber);

  try {
    if (!phoneNumber.startsWith("+")) {
      phoneNumber = `+91${phoneNumber}`;
    }
    console.log("Formatted phone number:", phoneNumber);

    const user = await User.findOne({ phoneNumber });
    console.log("User found:", user ? "Yes" : "No");
    if (!user) {
      return res.status(404).json({
        success: false,
        message: "No user found with this phone number. Please sign up first.",
      });
    }

    const otp = generateOTP();
    console.log("Generated OTP:", otp);
    const message = `Your OTP for password reset is: ${otp}`;
    const smsSent = await sendSMS(phoneNumber, message);
    console.log("SMS sent successfully:", smsSent);

    if (!smsSent) {
      return res.status(500).json({ success: false, message: "Failed to send OTP" });
    }

    user.otp = otp;
    user.otpExpires = Date.now() + 10 * 60 * 1000;
    await user.save();
    console.log("OTP saved to user");

    res.json({ success: true, message: "OTP sent successfully" });
  } catch (error) {
    console.error("Error in /send-otp:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
});
// Verify OTP Endpoint
app.post("/verify-otp", async (req, res) => {
  let { phoneNumber, otp } = req.body;

  try {
    if (!phoneNumber.startsWith("+")) {
      phoneNumber = `+91${phoneNumber}`;
    }

    const user = await User.findOne({ phoneNumber });
    if (!user) {
      return res.status(404).json({ verified: false, message: "User not found" });
    }

    if (user.otp !== otp || Date.now() > user.otpExpires) {
      return res.status(400).json({ verified: false, message: "Invalid or expired OTP" });
    }

    user.otp = undefined;
    user.otpExpires = undefined;
    await user.save();

    res.json({ verified: true, message: "OTP verified successfully"
    });
  } catch (error) {
    console.error("Error in /verify-otp:", error);
    res.status(500).json({ verified: false, message: "Internal server error" });
  }
});

// Reset Password Endpoint
app.post("/reset-password", async (req, res) => {
  let { phoneNumber, newPassword } = req.body;

  try {
    if (!phoneNumber.startsWith("+")) {
      phoneNumber = `+91${phoneNumber}`;
    }

    const user = await User.findOne({ phoneNumber });
    if (!user) {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    user.password = newPassword;
    await user.save();

    res.json({ success: true, message: "Password reset successfully" });
  } catch (error) {
    console.error("Error in /reset-password:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
});

// Existing Routes
app.use("/api/recipes", recipeRoutes);
app.use("/api", userRoute);

// Start Server
app.listen(PORT, () => {
  console.log(`Server is running on ${PORT}`);
});