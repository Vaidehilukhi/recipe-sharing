require('dotenv').config();
const express = require("express");
const router = express();

router.use(express.json());



module.exports=router;